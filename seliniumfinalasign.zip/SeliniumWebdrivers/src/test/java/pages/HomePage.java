package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;
import java.util.Random;

public class HomePage {
    WebDriver driver;

    public HomePage(WebDriver driver) {
        this.driver = driver;
    }

    public String selectRandomCategory() {
        List<WebElement> categories = driver.findElements(By.cssSelector(".nav-pills.categorymenu > li > a"));
        
        if (categories.size() == 0) {
            System.out.println("No categories found!");
            return null;
        }

        Random rand = new Random();
        int index = rand.nextInt(categories.size());
        WebElement selectedCategory = categories.get(index);
        
        String categoryName = selectedCategory.getText();
        System.out.println("Selected category: " + categoryName);
        selectedCategory.click();

        return categoryName;
    }
}
