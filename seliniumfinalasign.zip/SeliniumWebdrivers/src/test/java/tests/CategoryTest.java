package tests;

import org.testng.Assert;
import org.testng.annotations.Test;
import pages.HomePage;
import utils.DriverSetup;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import java.util.List;

public class CategoryTest extends DriverSetup {

    @Test
    public void verifyRandomCategoryHasProducts() {
        // Step 1: Open the website
        driver.get("https://automationteststore.com");

        // Step 2: Select a random category using HomePage object
        HomePage home = new HomePage(driver);
        String categoryName = home.selectRandomCategory();

        // Step 3: Wait and count product thumbnails
        List<WebElement> products = driver.findElements(By.cssSelector(".fixed_wrapper .prdocutname"));

        // Step 4: Assert at least 3 products
        System.out.println("Category '" + categoryName + "' has " + products.size() + " products.");
        Assert.assertTrue(products.size() >= 3, "Less than 3 products found in selected category!");
    }
}
