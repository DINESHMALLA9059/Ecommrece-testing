package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import java.util.Map;

public class RegistrationTest {
    WebDriver driver;

    public RegistrationTest(WebDriver driver) {
        this.driver = driver;
    }

    public void fillForm(Map<String, String> data, boolean skipField) {
        driver.findElement(By.name("firstname")).sendKeys(data.get("FirstName"));
        if (!skipField) {
            driver.findElement(By.name("lastname")).sendKeys(data.get("LastName"));
        }
        driver.findElement(By.name("email")).sendKeys(data.get("Email"));
        driver.findElement(By.name("password")).sendKeys(data.get("Password"));
    }

    public void submitForm() {
        driver.findElement(By.cssSelector("button[title='Continue']")).click();
    }

    public String getValidationMessage() {
        return driver.findElement(By.cssSelector(".alert.alert-error")).getText();
    }
}
