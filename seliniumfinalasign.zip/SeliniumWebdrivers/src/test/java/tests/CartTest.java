package tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;
import pages.HomePage;
import pages.CartPage;
import java.time.Duration;

public class CartTest {

    WebDriver driver;
    HomePage homePage;
    CartTest cartPage;

    @BeforeMethod
    public void setUp() {
        // Initialize WebDriver
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
        driver.manage().window().maximize();

        // Initialize page objects
        homePage = new HomePage(driver);
        cartPage = new CartPage(driver);
    }

    @Test
    public void testAddProductsToCart() {
        // Navigate to site
        homePage.goToHomePage();

        // Random category
        homePage.clickRandomCategory();

        // Add 2 random products
        cartPage.addRandomProductsToCart(2);
    }

    @AfterMethod
    public void tearDown() {
        driver.quit();
    }
}
